__license__ = 'MIT'
__version__ = '0.1'
__maintainer__ = ['Avinash Kori']
__email__ = ['koriavinash1@gmail.com']
