import numpy as np

def correct_image(img, size):
    pass
